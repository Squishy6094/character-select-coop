extern const GeoLayout custom_model_star_geo[];
extern Lights1 custom_model_star_f3dlite_material_lights;
extern Vtx custom_model_star_Suzanne_mesh_layer_1_vtx_0[1964];
extern Gfx custom_model_star_Suzanne_mesh_layer_1_tri_0[];
extern Gfx mat_custom_model_star_f3dlite_material[];
extern Gfx custom_model_star_Suzanne_mesh_layer_1[];
extern Gfx custom_model_star_material_revert_render_settings[];
