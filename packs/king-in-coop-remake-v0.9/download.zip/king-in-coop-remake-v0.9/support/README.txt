IMPORTANT:
The .lua files in the "support" folder are intended to be used as plugins to work better with certain mods that aren't built with king in mind.
(Some mods will have their support in the "support.lua" file in the main folder, nothing needs to be changed for those to work unless stated in the -- commented text.)

Currently supported mods:
    - Arena (kind of) -- Arena doesn't work yet, but I talked with DJ and an update is planned for Arena
                      -- which adds special globals that other mods can change for better support.
                      -- Once the update is out, King should work perfectly with Arena.

Planned mods:

    - Super Mario Kart 64 -- I plan to add TWO slots for Kart
                          -- Extra slot 1: King (Just regular King in a kart)
                          -- Extra slot 2: King R (King but he runs on foot, like in Sonic R)